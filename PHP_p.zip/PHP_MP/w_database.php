<?php
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if(isset($_GET['name'], $_GET['email'], $_GET['address'], $_GET['mobile'], $_GET['qty']) && 
   !empty($_GET['name']) && !empty($_GET['email']) && !empty($_GET['address']) && !empty($_GET['mobile']) && !empty($_GET['qty'])) {

    $name = test_input($_GET['name']);
    $email = test_input($_GET['email']);
    $address = test_input($_GET['address']);
    $mobile = test_input($_GET['mobile']);
    $qty = test_input($_GET['qty']);

    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
        exit(header("Location: ./Regi_form.php?msg=Invalid name format"));
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        exit(header("Location: ./Regi_form.php?msg=Invalid email format"));
    }

    if (!preg_match("/^[0-9]{10}$/", $mobile)) {
        exit(header("Location: ./Regi_form.php?msg=Invalid mobile number format"));
    }

    if (!preg_match("/^[1-9][0-9]*$/", $qty)) {
        exit(header("Location: ./Regi_form.php?msg=Invalid quantity format"));
    }

        $con= mysqli_connect("localhost","root","","mpdb");
         $sql= "INSERT INTO pizza_db(name, email, address, mobile, qty) VALUES ('$name','$email','$address','$mobile','$qty')";
   
         if(mysqli_query($con,$sql))
         {
             exit(header("Location: ./Regi_form.php?msg=Application Form Registered Successfully"));
         }
         else
         {
             $error=mysqli_error($con);
             exit(header("Location: ./Regi_form.php?msg=$error"));
         }
    
} else {
    exit(header("Location: ./Regi_form.php?msg=Invalid Request!"));
}
?>





<!--   -->
     