<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $email = $address = $mobile = $qty = "";

    if (empty($_GET["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_GET["name"]);
        // Check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
            $nameErr = "Only letters and white space allowed";
        }
    }

    if (empty($_GET["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_GET["email"]);
        // Check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    if (empty($_GET["address"])) {
        $addressErr = "Address is required";
    } else {
        $address = test_input($_GET["address"]);
    }

    if (empty($_GET["mobile"])) {
        $mobileErr = "Mobile number is required";
    } else {
        $mobile = test_input($_GET["mobile"]);
        // Check if mobile number contains only numbers
        if (!preg_match("/^[0-9]{10}$/",$mobile)) {
            $mobileErr = "Invalid mobile number format";
        }
    }

    if (empty($_GET["qty"])) {
        $qtyErr = "Quantity is required";
    } else {
        $qty = test_input($_GET["qty"]);
        // Check if quantity is a positive integer
        if (!preg_match("/^[1-9][0-9]*$/",$qty)) {
            $qtyErr = "Invalid quantity format";
        }
    }

    // If all fields are valid, process the form data
    if (empty($nameErr) && empty($emailErr) && empty($addressErr) && empty($mobileErr) && empty($qtyErr)) {
        // Process the form data, for example, save it to a database
        // Redirect to a success page or do something else
        header("Location: success.php");
        exit();
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
