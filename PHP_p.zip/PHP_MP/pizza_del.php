<?php
    extract($_GET);
    if(isset($id) && !empty($id)){
    $con= mysqli_connect("localhost","root","","mpdb");
    $sql= "DELETE from pizza_db where id = '{$id}'";
    if(mysqli_query($con,$sql))
    {
        exit(header("location: ./pizza_tb.php?msg=Row deleted successfully!!!"));
    }else
    {
        exit(header("location: ./pizza_tb.php?msg=Something went wrong please try again!!!"));
    }
}
?>