<html>
    <head>
        <style>
            table {
            width: 100%;
            border: 1px solid black;
            text-align: center;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        input[type='button'] {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type='button']:hover {
            background-color: #45a049;
        }
        </style>
    </head>
    <body>
        <table width="100%" border="1px solid black" style="text-align:center">
            <tr>
                <td><b>Id</b></td>
                <td><b>Name</b></td>
                <td><b>Email</b></td>
                <td><b>Address</b></td>
                <td><b>Mobile</b></td>
                <td><b>Quantity</b></td>
                <td><b>Action</b></td>

                </tr>

                <?php
                $con=mysqli_connect("localhost","root","","mpdb");
                $sql="SELECT * FROM pizza_db";
                $result=mysqli_query($con,$sql);

                while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
                {
                    extract($row);
                
                    echo"
                    <tr>
                        <td>$id</td>
                        <td>$name</td>
                        <td>$email</td>
                        <td>$address</td>
                        <td>$mobile</td>
                        <td>$qty</td>

                        <td><input type='button' name='id' value='Delete' onclick='location.href=\"pizza_del.php?id=$id\"'></td>
                       

                    </tr>";
                }
                ?>

            </table>

            
    </body>
    </html>