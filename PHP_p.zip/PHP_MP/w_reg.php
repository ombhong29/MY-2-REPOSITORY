<html>
    <body>
        <table width="100%" border="1px solid black" style="text-align:center">
            <tr>
                <td>name</td>
                <td>email</td>
                <td>address</td>
                <td>mobile</td>
        
                
                
                <td>Quantity</td>
                

                </tr>

                <?php
                $con=mysqli_connect("localhost","root","","sample");
                $sql="SELECT * FROM watch_reg";
                $result=mysqli_query($con,$sql);

                while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
                {
                    extract($row);
                
                    echo"
                    <tr>
    
                        <td>$name</td>
                        <td>$email</td>
                        <td>$address</td>
                        <td>$mobile</td>
                        <td>$qty</td>
                    

                        

                    </tr>";
                }
                ?>

            </table>

            
    </body>
    </html>